package Exceptions;

/**
 * 
 * @author charlie
 *
 */
public class FTPDisconnexionException extends RuntimeException{

}
