package Exceptions;

/**
 * 
 * @author charlie
 *
 */
public class FTPConnexionException extends RuntimeException{

}
